#include <QGuiApplication>

#include <QQuickView>
#include <QQmlApplicationEngine>
#include <QQuickItem>

#include "myobj.h"


int main(int argc, char *argv[])
{
    QGuiApplication theApp(argc, argv);


    QQuickView view;
    view.setSource(QUrl("qrc:///main.qml"));


    QObject::connect((QObject*)view.engine(), SIGNAL(quit()), &theApp, SLOT(quit()));

    QQuickItem *pQMLRectangle = view.rootObject();
    myobj *pMyObject = new myobj();



    QObject::connect (
                pQMLRectangle,
                SIGNAL (qmlSignal (int)),
                pMyObject,
                SLOT (onQMLSignal (int))
                );

    QObject::connect (
                pMyObject,
                SIGNAL (updatePictureSignal(QVariant)),
                pQMLRectangle,
                SLOT (onUpdatePictureSignal (QVariant))
                );


    view.show();

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return theApp.exec();
}
