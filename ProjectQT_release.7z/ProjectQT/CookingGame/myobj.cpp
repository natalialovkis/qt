#include "myobj.h"

myobj::myobj (QObject *parent) : QObject(parent)
{

}

void myobj::onQMLSignal(int message){
    qDebug()<<"in object ->"<<message<<endl;
    if(message == 33)
    {
        st = "bakedApples";
    }
    else if(message == 51)
    {
        st = "applePie";
    }
    else if(message == 42)
    {
        st = "dessert";
    }
    else if(message == 60)
    {
        st = "pancakes";
    }
    else
    {
        st = "noFood";
    }

    emit updatePictureSignal ( st );

}
