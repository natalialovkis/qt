#ifndef MYOBJ_H
#define MYOBJ_H

#include <QObject>
#include <QDebug>

class myobj: public QObject
{
    Q_OBJECT
public:
    explicit myobj(QObject *parent = 0);

private:
    QString st;

signals:
    void updatePictureSignal( QVariant );

private slots:
    void onQMLSignal (int);
};

#endif // MYOBJ_H
